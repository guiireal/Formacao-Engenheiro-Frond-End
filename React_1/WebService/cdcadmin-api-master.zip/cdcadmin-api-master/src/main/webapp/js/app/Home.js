export class Home extends React.Component {
	render() {
		return(
		<div id="main">
			<h1>Pagina de Cadastro de Livros</h1>
		</div>
		);
	}
}