#Pequena explicação

Projeto da API exposta no curso 1 de React no alura.  	

